Read me for Digit sounds.

Date: 2019/07/07 
Writer: Jonghwa Park

Material: 0~9 Digit narration sounds
Duration: 1 sec, each

===Recording protocol===
Microphone: Lewitt LCT 440 pure
Software: Adobe Audition 3.0
Audio interface: Yamaha ag03
Recorded inside of Sound proof room
Professional Female Narrator


issue: 3과 4의 Vowel onset time 이 좀 긴 것 같아서 delay처럼 느껴지는 현상이 있었음.
>>> 3, 4를 제외한 모든 파일 앞에 0.1초의 여백을 두도록 조정.

